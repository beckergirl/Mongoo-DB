// reto 2 MONGO DB (modulo 5)

//ESQUEMAS Y MODELOS:

const mongoose = require("mongoose");


// VALIDACIÓN:

const ProfileSchema = new mongoose.Schema({

    name: String,
    surname: {
        type: String,
        validate: [
            function(surname){

                return surname.lenght >= 3;
            },
            "El apellido debería ser más largo"],
            select: false
    },
    dateOfBirth: Number,
    comments: String,
    role: String
 
})

// MIDDELEWARE: (pre y tambien vale el post)

ProfileSchema.pre("save", function(next){

    console.log("Middlelware de entrada");
    if(this.name > 2){

        console.log("Has introducido un nombre muy corto")
        next();

    }else{

        console.log("Solo nombres mayores de 2 letras");
    }
});

module.exports = mongoose.model("Profile", ProfileSchema); 