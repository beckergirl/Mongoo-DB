    
//USO DEL MODELO:

const mongoose = require("mongoose");
let Credentials = require("./credentialsMBD");


mongoose.connect('mongodb+srv://Becker:Becker82@cluster0.ta8owdb.mongodb.net/codenotch2',
               {useNewUrlParser: false, useUnifiedTopology: false });

let credentialsDocument = new Credentials({

    adress: "C/ miraflor, 25",
    phone: 555432234,
    email: "linus_1986@gmail.es",
   
});

//USO DEL MODELO:

credentialsDocument.save(checkRespuesta)

function checkRespuesta(err, res){


    if(err){

        console.log("Error: " + err);

    }else{

        console.log("Documento guardado correctamente");
      /*   mongoose.disconnect(); */

    }
}

