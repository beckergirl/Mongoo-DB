// reto 2 MONGO DB (modulo 5)

//ESQUEMAS Y MODELOS:

const mongoose = require("mongoose");

// VALIDACIÓN:

const CredentialsSchema = new mongoose.Schema({

    adress: String,
    phone: Number,

    email: {

            type: String,
            required: true
        },
    }
   
)

//  MIDDELEWARE: (pre y tambien vale el post)

CredentialsSchema.pre("save", function(next){

    console.log("Middlelware de entrada");
    if(this.phone >= 9){

        console.log("Has introducido un número muy corto")
        next();

    }else{

        console.log("Solo números de 9 dígitos o mayores");
    }
});


module.exports = mongoose.model("Credentials", CredentialsSchema); 