    
//USO DEL MODELO:

const mongoose = require("mongoose");
let Profile = require("./ProfileMBD");


mongoose.connect('mongodb+srv://Becker:Becker82@cluster0.ta8owdb.mongodb.net/codenotch2',
               {useNewUrlParser: false, useUnifiedTopology: false });

let profileDocument = new Profile({

    name: "Ana",
    surname: "Granuja",
    dateOfBirth: 1990-07-18,
    comments: "Loren ipsum, hwcvbjhwbdchwbd hjwvbdchjdjhvcy",
    role: "usuario"
   
});

//USO DEL MODELO:

profileDocument.save(checkRespuesta)

function checkRespuesta(err, res){

    if(err){

        console.log("Error: " + err);

    }else{

        console.log("Documento guardado correctamente");
      /*   mongoose.disconnect(); */

    }
}

