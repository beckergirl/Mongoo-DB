
//USO DEL MODELO:

const mongoose = require("mongoose");
let User = require("./userMBD");


mongoose.connect('mongodb+srv://Becker:Becker82@cluster0.ta8owdb.mongodb.net/codenotch2',
               {useNewUrlParser: false, useUnifiedTopology: false });

let userDocument = new User({

    login: "Mina75",
    password: "1234567",
   
});

//USO DEL MODELO:

userDocument.save(checkRespuesta)

function checkRespuesta(err, res){

    if(err){

        console.log("Error: " + err);

    }else{

        console.log("Documento guardado correctamente");
       mongoose.disconnect();

    }
}
