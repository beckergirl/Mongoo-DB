// reto 2 MONGO DB (modulo 5)

//ESQUEMAS Y MODELOS:

const mongoose = require("mongoose");
 

// VALIDACIÓN:

let UserSchema = new mongoose.Schema({

    login: String,

    password: {

        type: String,
        validate: [
            function(password){

                return password.lenght >= 6;
            },
            "El password debería ser más largo"],
            select: false
    }
  
})

//MIDDELEWARE: (pre y tambien vale el post)

UserSchema.pre("save", function(next){

    console.log("Middlelware de entrada");
    if(this.login.length >= 8){

        console.log("Has introducido un login más corto")
        next();

    }else{

        console.log("Solo login de más de 8 letras");
    }
}); 

module.exports = mongoose.model("User", UserSchema); 